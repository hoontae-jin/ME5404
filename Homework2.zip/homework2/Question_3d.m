clc; clear; clear all

load('whole_dataset.mat');
% 900 images/labels for training, and 100 for validation 
train_data_dog = whole_dataset(1:end-1, 1:450);
train_data_automobile = whole_dataset(1:end-1, 501:950);
whole_train_data = [train_data_dog train_data_automobile];

train_label_dog = whole_dataset(end, 1:450);
train_label_automobile = whole_dataset(end, 501:950);
whole_train_label = [train_label_dog train_label_automobile];

val_data_dog = whole_dataset(1:end-1, 451:500);
val_data_automobile = whole_dataset(1:end-1, 951:1000);
whole_val_data = [val_data_dog val_data_automobile];

val_label_dog = whole_dataset(end, 451:500);
val_label_automobile = whole_dataset(end, 951:1000);
whole_val_label = [val_label_dog val_label_automobile];

all_data = horzcat(whole_train_data, whole_val_data);
all_label = horzcat(whole_train_label, whole_val_label);

whole_train_num = size(whole_train_data,2);
whole_val_num = size(whole_val_data,2);

net = patternnet(60,'traingdx','crossentropy');
net.divideFcn = 'divideind';
net.divideParam.trainInd = 1:900;
net.divideParam.valInd = 901:1000;

net.trainParam.epochs= 1000;
net.trainParam.lr=0.01;
net.trainParam.max_fail = 1000;
net.trainParam.goal=0.00000001;
% net.performParam.regularization = 0.2; %Try out with any value

[net, tr] = train(net, all_data, all_label);

