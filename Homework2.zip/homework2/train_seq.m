
function [ net, accu_train, accu_val ] = train_seq( n, images, labels, train_num, val_num, epochs )   
    % 1. Change the input to cell array form for sequential training
    images_c = num2cell(images, 1);
    labels_c = num2cell(labels, 1);
    
    % 2. Construct and configure the MLP
    net = patternnet(n);
    net.divideFcn = 'dividetrain'; % input for training only
    net.performParam.regularization = 0.25; % regularization strength
    net.trainFcn = 'trainscg';
    net.trainParam.epochs = epochs;
    net.inputWeights{1,1}.learnParam.lr = 0.003;
    net.layerWeights{2,1}.learnParam.lr = 0.003;
    net.biases{1}.learnParam.lr = 0.003;
    net.biases{2}.learnParam.lr = 0.003;
    accu_train = zeros(epochs,1); % record accuracy on training set of each epoch
    accu_val = zeros(epochs,1); % record accuracy on validation set of each epoch
    
    % 3. Train the network in sequential mode
    for i = 1 : epochs
        display(['Epoch: ', num2str(i)])
        idx = randperm(train_num); % shuffle the input
        net = adapt(net, images_c(:,idx), labels_c(:,idx));
        pred_train = round(net(images(:,1:train_num))); % predictions on training set
        accu_train(i) = 1 - mean(abs(pred_train-labels(1:train_num)));
        pred_val = round(net(images(:,train_num+1:end))); % predictions on validation set
        accu_val(i) = 1 - mean(abs(pred_val-labels(train_num+1:end)));
        % disp(sim(net,0))
    end
    
    end
