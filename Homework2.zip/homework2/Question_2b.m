clear; clc; close all;
%% sampling points in the domain of [-1.6,1.6] and [-3, 3]
training_x_input = -1.6:0.05:1.6;
OutDomain_x_input = -3:0.01:3;
%% generating training data, and the desired outputs
y = 1.2*sin(pi*training_x_input)-cos(2.4*pi*training_x_input);
y2 = 1.2*sin(pi*OutDomain_x_input)-cos(2.4*pi*OutDomain_x_input);
%% specify the structure and learning algorithm for MLP
for n = [1:10, 20, 50, 100]
    disp(n);
    net = fitnet(n,'trainlm');
    net = configure(net,training_x_input,y);
    net.trainparam.lr=0.01;
    net.trainparam.epochs=100;
    net.trainparam.goal=1e-7;
    net.divideParam.trainRatio=0.7;
    net.divideParam.testRatio=0.3;
    %% Train the MLP
    [net,tr]=train(net,training_x_input,y);
    %% Test the MLP [-1.6, 1.6]
    test_x_input=-1.6:0.01:1.6;
    test_x_input2=-3:0.01:3;
    net_output=sim(net,test_x_input);
    net_output2=sim(net,test_x_input2);
    % Plot out the test results
    figure
    plot(OutDomain_x_input, y2)
    hold on;
    plot(test_x_input,net_output(1, :),'r', 'LineWidth', 5);
    hold on;
    plot(test_x_input2,net_output2(1, :),'k', 'LineWidth', 1.5);
    line([-1.6 -1.6], [min(net_output2) max(net_output2)],'Color','magenta', 'LineStyle','--');
    line([1.6 1.6], [min(net_output2) max(net_output2)],'Color','magenta', 'LineStyle','--');
    legend('target function', 'MLP result [-1, 1]', 'MLP result [-3, 3]','Original domain')
    title(strcat("1-", num2str(n), "-1 on sequential mode"," with trainlm"))
    xlabel('x')
    ylabel('y')
    hold off
end