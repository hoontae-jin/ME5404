clc; clear;
% If the code does not work, please ensure that you run the script
% named "data_processsing" to install the desired dataset first
clc; clear; close all;
%% My Student ID : A0243155L
mod(55,3) % 1
%% Q3-a

load('whole_dataset.mat');
% 900 images/labels for training, and 100 for validation 
train_data_dog = whole_dataset(1:end-1, 1:450);
train_data_automobile = whole_dataset(1:end-1, 501:950);
whole_train_data = [train_data_dog train_data_automobile];

train_label_dog = whole_dataset(end, 1:450);
train_label_automobile = whole_dataset(end, 501:950);
whole_train_label = [train_label_dog train_label_automobile];

val_data_dog = whole_dataset(1:end-1, 451:500);
val_data_automobile = whole_dataset(1:end-1, 951:1000);
whole_val_data = [val_data_dog val_data_automobile];

val_label_dog = whole_dataset(end, 451:500);
val_label_automobile = whole_dataset(end, 951:1000);
whole_val_label = [val_label_dog val_label_automobile];

whole_train_num = size(whole_train_data,2);
whole_val_num = size(whole_val_data,2);

train_accuracy_dataset = [];
validation_accuracy_dataset = [];
% Rosenblatt Single-layer network 
for epoch = 10:10:100;
    net = perceptron('hardlim', 'learnp');
    net.trainParam.epochs= epoch;
    net.divideFcn = 'dividetrain';

    net = train(net, whole_train_data, whole_train_label);

    output_train = sim(net, whole_train_data);
    output_val = sim(net, whole_val_data);
    train_accuracy = 0;
    val_accuracy = 0;
    for i=1:whole_train_num
        if abs(output_train(i) - whole_train_label(i)) == 0 
            train_accuracy = train_accuracy+ 1;
        end
    end
    for i=1:whole_val_num
        if abs(output_val(i) - whole_val_label(i)) == 0
            val_accuracy = val_accuracy+ 1;
        end
    end
    train_accuracy = train_accuracy/whole_train_num
    validation_accuracy = val_accuracy/whole_val_num

    train_accuracy_dataset = [train_accuracy_dataset, train_accuracy, ];
    validation_accuracy_dataset = [validation_accuracy_dataset, validation_accuracy];
end

x = 10:10:100;
y = [train_accuracy_dataset; validation_accuracy_dataset];
plot(x, y*100)
ylim([49 55])
legend("training accuracy", "validation accuracy")
xlabel("Iterations")
ylabel("Accuracy (%)")