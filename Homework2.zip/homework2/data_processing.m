clc; clear; close all;

dog_path = strcat(pwd, '\dog\');
automobile_path = strcat(pwd, '\automobile\');

[dog_data] = dataprocessing(dog_path);
[airplane_data] = dataprocessing(automobile_path);
dog_label = ones(1,500);
automobile_label = zeros(1,500);

dog_dataset = vertcat(dog_data, dog_label);
automobile_dataset = vertcat(airplane_data, automobile_label);
whole_dataset = [dog_dataset automobile_dataset];
save('whole_dataset.mat', 'whole_dataset');

function [data] = dataprocessing(file_path)
    images = dir(strcat(file_path, '*.jpg'));
    num_images = size(images, 1);

    image_list = cell(1, num_images);
    data = zeros(32*32, 500);

    for i=1:num_images
        image_name = (strcat(file_path, images(i).name));
        img = double(rgb2gray(imread(num2str(image_name))));
        image_list{:, i} = img;

    end
    image_list_mat = cell2mat(image_list);
    data = reshape(image_list_mat, [], num_images);
end
